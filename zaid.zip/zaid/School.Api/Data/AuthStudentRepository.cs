using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using School.Api.Models;

namespace School.Api.Data
{
    public class AuthStudentRepository: IAuthStudentRepository
    {
     private readonly DataContext _context;
        public AuthStudentRepository(DataContext context)
        {
            this._context = context;
        }
        public async Task<User> Login(string username, string password)
        {
            var user = _context.Students.FirstOrDefault(x => x.Username == username);
            long userSsn, passSsn;
            if(user == null && long.TryParse(username, out userSsn) && long.TryParse(password, out passSsn))
                return await LoginSsn(userSsn, passSsn);
            if(!VerifyPasswordHash(password, user.PasswordHash,user.PasswordSalt)){
                        return null;
            }
            return user;
        }

        private bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            bool isVerified = true;
            using(var hmac = new System.Security.Cryptography.HMACSHA512(passwordSalt)){
                
                var ComputedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                for(int i = 0; i < ComputedHash.Length; i++){
                    if(ComputedHash[i] != passwordHash[i]) isVerified = false;
                }
            }
            return isVerified;
            

        }

        public async Task<User> Register(Student student, string password)
        {
            byte [] passwordHash, passwordSalt;
            CreatePasswordHash(password, out passwordHash, out passwordSalt);
            Student std = await _context.Students.FindAsync(student.Ssn);
            std.PasswordHash = passwordHash;
            std.PasswordSalt = passwordSalt;
            std.Ssn = student.Ssn;
            std.Username = student.Username;
            await _context.SaveChangesAsync();
            return student;
        }

        public async Task<bool> UserExists(string username)
        {
            bool isExist = false;
            if(await _context.Students.AnyAsync(u=> u.Username == username))
                isExist = true;
            return isExist;
        }

        private void  CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt){
         
         using(var hmac = new System.Security.Cryptography.HMACSHA512()){
             passwordSalt = hmac.Key;
             passwordHash = hmac.ComputeHash(
                 System.Text.Encoding.UTF8.GetBytes(password)
            );
         }
        }
        private async Task<User> LoginSsn(long username, long password)
        {
            User user = null;
            if(username != password)
                return  user;
            try{            
                user = await _context.Students.SingleOrDefaultAsync(u => u.Ssn == username);
            }catch(Exception e){
                Console.WriteLine(e);
            }
            Console.WriteLine("allah akber");
            return user;
        }
    }
}