using System.Collections.Generic;
using System.Threading.Tasks;
using School.Api.Models;

namespace School.Api.Data
{
    public interface IDataRepository
    {
        Task<Teacher> GetInfoTeacher(long ssn);

        Task<Parent> GetInfoParent(long ssn);

        Task<Student> GetInfoStudent(long ssn);

        Task<IEnumerable<Subject>> GetSubjectsByStage(long stageId);

        Task<IEnumerable<Lesson>> GetLessonBySubject(int subjectId);
        Task<IEnumerable<Marks>> GetMarksBySsn(int ssn);
    }
}