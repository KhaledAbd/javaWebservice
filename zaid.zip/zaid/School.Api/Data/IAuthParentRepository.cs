using System.Threading.Tasks;
using School.Api.Models;

namespace School.Api.Data
{
    public interface IAuthParentRepository
    {
        
        Task<User> Register(Parent user, string password);

         Task<User> Login(string username, string password);

         Task<bool> UserExists(string username);

         Task<User> LoginSsn(string username, string password); 
    }
}