using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using School.Api.Models;

namespace School.Api.Data
{
    public class DataRepository: IDataRepository
    {
        private readonly DataContext context;
        public DataRepository(DataContext context) { 
            this.context = context;
        }
        public Task<Parent> GetInfoParent(long ssn)
        {
            return context.Parents.Include(s => s.Students).ThenInclude(s=> s.StageNavigation)
                    .Include(s => s.Photos).SingleOrDefaultAsync(p => p.Ssn == ssn);
        }

        public Task<Student> GetInfoStudent(long ssn)
        {
            return context.Students.Include(s => s.StageNavigation)
                    .Include(s => s.Photos).SingleOrDefaultAsync(p => p.Ssn == ssn);
        }

        public async  Task<Teacher> GetInfoTeacher(long ssn)
        {
            return await context.Teachers.Include(s => s.Photos).SingleOrDefaultAsync(p => p.Ssn == ssn);
        }

        public async Task<IEnumerable<Lesson>> GetLessonBySubject(int subjectId)
        {
            return await context.Lessons.Where(l => l.SubjectId == subjectId).ToListAsync();
        }

        public async Task<IEnumerable<Subject>> GetSubjectsByStage(long stageId)
        {
            return await context.Subjects.Where(s => s.StageId == stageId).ToListAsync();
        }

        public async Task<IEnumerable<Marks>> GetMarksBySsn(int ssn){
            return await context.Marks.Include(m => m.SubjectNavigation)
            .Include(m=> m.StudentNavigation).Where(s => s.StudentId == ssn).ToListAsync();
        }

    }
}