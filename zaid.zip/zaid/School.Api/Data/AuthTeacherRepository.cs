using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using School.Api.Models;

namespace School.Api.Data
{
    public class AuthTeacherRepository: IAuthTeacherRepository
    {
        private readonly DataContext _context;
        public AuthTeacherRepository(DataContext context)
        {
            this._context = context;
        }
        public async Task<User> Login(string username, string password)
        {
            var user = await _context.Teachers.FirstOrDefaultAsync(x => x.Username == username);
            if(user == null)
                return await LoginSsn(username, password);
            if(!VerifyPasswordHash(password, user.PasswordHash,user.PasswordSalt)){
                        return null;
            }
            
            return user;
        }

        private bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            bool isVerified = true;
            using(var hmac = new System.Security.Cryptography.HMACSHA512(passwordSalt)){
                
                var ComputedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                for(int i = 0; i < ComputedHash.Length; i++){
                    if(ComputedHash[i] != passwordHash[i]) isVerified = false;
                }
            }
            return isVerified;
            

        }

        public async Task<User> Register(Teacher teacher, string password)
        {
            byte [] passwordHash, passwordSalt;
            CreatePasswordHash(password, out passwordHash, out passwordSalt);
            Teacher tch = await _context.Teachers.FindAsync(teacher.Ssn);
            tch.PasswordHash = passwordHash;
            tch.PasswordSalt = passwordSalt;
            await _context.SaveChangesAsync();
            return teacher;
        }

        public async Task<bool> UserExists(string username)
        {
            bool isExist = false;
            if(await _context.Teachers.AnyAsync(u=> u.Username == username))
                isExist = true;
            return isExist;
        }

        private void  CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt){
         
         using(var hmac = new System.Security.Cryptography.HMACSHA512()){
             passwordSalt = hmac.Key;
             passwordHash = hmac.ComputeHash(
                 System.Text.Encoding.UTF8.GetBytes(password)
            );
         }
        }

        public async Task<User> LoginSsn(string username, string password)
        {
            User user = null;
            if(string.IsNullOrEmpty(username) && string.IsNullOrEmpty(password) && username.Equals(password))
                return  user;
            int ssn = 0;
            try{
                ssn = int.Parse(username);
                user = await _context.Teachers.SingleOrDefaultAsync(u => u.Ssn == ssn);
            }catch(Exception e){
                Console.WriteLine(e);
            }
            return user;
        }

       
    }
}