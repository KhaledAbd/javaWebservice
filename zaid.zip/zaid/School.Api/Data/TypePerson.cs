namespace School.Api.Data
{
    public enum TypePerson
    {
        Student,
        Teacher,
        Parent
    }
}