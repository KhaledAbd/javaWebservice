using System.Threading.Tasks;
using School.Api.Models;

namespace School.Api.Data
{
    public interface IAuthStudentRepository
    {
        Task<User> Register(Student user, string password);

         Task<User> Login(string username, string password);

         Task<bool> UserExists(string username);

    }
}