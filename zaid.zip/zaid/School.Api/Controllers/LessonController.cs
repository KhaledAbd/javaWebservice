using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using School.Api.Data;
using School.Api.Dto;

namespace School.Api.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/lesson/{userSsn}")]
    public class LessonController: ControllerBase
    {
        private readonly IMapper mapper;
        private readonly IDataRepository repository;

        public LessonController(IMapper mapper, IDataRepository repository){
            this.mapper = mapper;
            this.repository = repository;
        }

        [HttpGet("{subjectId}")]
        public async Task<IActionResult> getLesson(int userSsn, int subjectId){
            if(userSsn != long.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();

            return Ok(mapper.Map<IEnumerable<LessonForReturnDto>>(await repository.GetLessonBySubject(subjectId)));
        }
    }
}