using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using School.Api.Data;
using School.Api.Dto;

namespace School.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/stage/{userSsn}")]
    public class StageController: ControllerBase
    {
        private readonly IDataRepository repository;
        private readonly IMapper mapper;

        public StageController(IDataRepository repository, IMapper mapper){
            this.repository = repository;
            this.mapper = mapper;
        }
        [HttpGet("student")]
        public async Task<IActionResult> getStudent (long userSsn){
            if(userSsn != long.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();

            return Ok(mapper.Map<UserForInfoStudentDto>(await repository.GetInfoStudent(userSsn)));
        }

        [HttpGet("teacher")]
        public async Task<IActionResult> getTeacher(long userSsn){
            if(userSsn != long.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();

            return Ok(mapper.Map<UserForInfoTeacherDto>(await repository.GetInfoTeacher(userSsn)));
        }
        [HttpGet("parent")]
        public async Task<IActionResult> getParent(long userSsn){
            if(userSsn != long.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();

            return Ok(mapper.Map<UserForInfoParentDto>(await repository.GetInfoParent(userSsn)));
        }
        
    }
}