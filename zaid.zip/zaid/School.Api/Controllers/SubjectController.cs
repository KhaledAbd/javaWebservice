using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using School.Api.Data;
using School.Api.Dto;

namespace School.Api.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/subject/{userSsn}")]
    public class SubjectController: ControllerBase
    {
        private readonly IDataRepository repository;
        private readonly IMapper mapper;

        public SubjectController(IDataRepository repository, IMapper mapper){
            this.repository = repository;
            this.mapper = mapper;
        }
        
        [HttpGet("{stageId}")]
        public async Task<IActionResult> GetSubject(long stageId, long userSsn){
            if(userSsn != int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();
            return Ok(mapper.Map<IEnumerable<SubjectForDto>>(await repository.GetSubjectsByStage(stageId)));
        }
    }
}