using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using School.Api.Data;
using School.Api.Dto;

namespace School.Api.Controllers
{
    [Authorize]
    [Route("/api/marks")]
    public class MarksController: ControllerBase
    {
        private readonly IDataRepository repository;
        private readonly IMapper mapper;

        public MarksController(IDataRepository repository, IMapper mapper){
            this.repository = repository;
            this.mapper = mapper;
        }

        [HttpGet("{ssn}")]
        public async Task<IActionResult> GetMarks(int ssn){
            if (ssn != int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();
            
            return Ok(mapper.Map<IEnumerable<MarksForStudentsDto>>(await repository.GetMarksBySsn(ssn)));
        }

        [HttpGet("student/{ssnStudent}/parent/{ssnParent}")]
        public async Task<IActionResult> GetMarksParent(int ssnStudent, int ssnParent){
            if (ssnParent != int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();

            return Ok(mapper.Map<IEnumerable<MarksForStudentsDto>>(await repository.GetMarksBySsn(ssnStudent)));
        }
    }
}