using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using School.Api.Data;
using School.Api.Dto;
using School.Api.Models;

namespace School.Api.Controllers
{
    [ApiController]
    [Route("api/parent")]
    public class ParentController : ControllerBase
    {
        private readonly IAuthParentRepository repository;
        private readonly IConfiguration config;
        private readonly IMapper mapper;
        private readonly IDataRepository dataRepository;

        public ParentController(IAuthParentRepository repository, IConfiguration config, IMapper mapper, IDataRepository dataRepository)
        {
            this.repository = repository;
            this.config = config;
            this.mapper = mapper;
            this.dataRepository = dataRepository;
        }


        [HttpPost("login")]
        public async Task<IActionResult> LoginParent(UserForLoginDto userForLoginDto)
        {
            var userFromRepo = await repository.Login(userForLoginDto.Username.ToString(), userForLoginDto.Password);
            if(userFromRepo == null)
                return Unauthorized();
  
            var claims = new [] {
                new Claim(ClaimTypes.NameIdentifier, userFromRepo.Ssn.ToString()),
            };
            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(config.GetSection("AppSettings:Token").Value));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);
            var tokenDescriptor = new SecurityTokenDescriptor(){
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = creds
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);

            var user = mapper.Map<UserForDetailsDto>(userFromRepo);
            user.Token = tokenHandler.WriteToken(token);
            return Ok(user);
        }
        [Authorize]
        [HttpPost("register/{ssn}")]
        /// --- http://localhost:5000/api/student/register/1
        public async Task<IActionResult> Register([FromBody] UserForRegisterDto userForRegister, int ssn)
        {
            if(ssn != int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value)){
                return Unauthorized();
            }
            userForRegister.Username = userForRegister.Username.ToLower();
            if (await repository.UserExists(userForRegister.Username))
            {
                return BadRequest("User Is Exist ...");
            }
            var user = mapper.Map<Parent>(userForRegister);
            user.Ssn = ssn;
            return Ok(mapper.Map<UserForDetailsDto>(await repository.Register(user, userForRegister.Password)));
        }
        [Authorize]
        [HttpGet("info/{ssn}")]
        public async Task<IActionResult> GetInfoParent(int ssn)  {
            if(ssn != int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value)){
                return Unauthorized();
            }
            return Ok(mapper.Map<UserForInfoParentDto>(await dataRepository.GetInfoParent(ssn)));
        }
    }
}