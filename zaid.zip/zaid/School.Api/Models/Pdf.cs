using System.ComponentModel.DataAnnotations.Schema;

namespace School.Api.Models
{
    public class Pdf
    {
        public long Id {get; set;}

        public string Description {get; set;}

        public string PublicId {get; set;}

        public string Url {get; set;}

        [ForeignKey("StageNavigation")]
        public long StageId {get; set;}
        
        public Stage StageNavigation {get; set;}
    }
}