using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace School.Api.Models
{
    public class Parent: User
    {
        [Key]
        public long Ssn {get; set;}

        public string Username  {get; set;}

        public byte[] PasswordHash {get; set;}

        public byte[] PasswordSalt {get; set;}

        public string Name {get; set;}

        public bool Gender {get; set;}

        public List<Photo> Photos {get; set;}

        public ICollection<Student> Students {get; set;}
    }
}