namespace School.Api.Models
{
    public interface User
    {
        long Ssn {get; set;}

        string Username  {get; set;}

        byte[] PasswordHash {get; set;}

        byte[] PasswordSalt {get; set;}   
    }
}