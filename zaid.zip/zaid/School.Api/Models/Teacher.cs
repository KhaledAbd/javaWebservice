using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace School.Api.Models
{
    public class Teacher: User
    {

        [Key]
        public long Ssn {get; set;}

        public string Username  {get; set;}

        public byte[] PasswordHash {get; set;}

        public byte[] PasswordSalt {get; set;}

        public string Name {get; set;}

        public List<Photo> Photos {get; set;}

        public bool Gender {get; set;}

        public ICollection<TeacherSubject> TeacherSubject { get; set; }
    
        public ICollection<TeacherStage> TeacherStages {get; set;}
    }
}