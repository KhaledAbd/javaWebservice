using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace School.Api.Models
{
    public class Student: User
    {
        [Key]
        public long Ssn {get; set;}

        public string Username  {get; set;}

        public byte[] PasswordHash {get; set;}

        public byte[] PasswordSalt {get; set;}

        public string Name {get; set;}

        public bool Gender {get; set;}
        
        public List<Photo> Photos {get; set;}

        [ForeignKey("StageNavigation")]
        public long StageId {get; set;}

        public Stage StageNavigation {get; set;}

        [ForeignKey("ParentNavigation")]
        public long ParentId {get; set;}

        public Parent ParentNavigation {get; set;}

    }
}