using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace School.Api.Models
{
    public class Subject
    {
        public long Id { get; set; }

        public string Name {get; set;}

        public decimal? FullMark {get; set;}

        public ICollection<Marks> marks {get; set;}

        [ForeignKey("StageNavigation")]
        public long StageId {get; set;}

        public Stage StageNavigation { get; set; }

        public ICollection<Lesson> Lessons {get; set;}

        public ICollection<TeacherSubject> TeacherSubjects {get; set;}
       
        [NotMapped]
        public ICollection<Marks> Marks {get; set;}

    }
}
