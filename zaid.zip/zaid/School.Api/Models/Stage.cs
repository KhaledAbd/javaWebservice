using System.Collections.Generic;

namespace School.Api.Models
{
    public class Stage
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public ICollection<Student> Students{get; set;}

        public ICollection<Subject> Subjects{get; set;}

        public ICollection<TeacherStage> TeacherStages {get; set;}
    }
}