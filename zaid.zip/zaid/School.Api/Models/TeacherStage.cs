using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace School.Api.Models
{
    public class TeacherStage
    {
        [Key]
        public long Id {get; set;}

        [ForeignKey("StageNavigation")]
        public long StageId {get; set;}

        Stage StageNavigation { get; set; }

        [ForeignKey("TeacherNavigation")]
        public long TeacherSsn {get; set;}
        
        public Teacher TeacherNavigation { get; set; }        
    }
}