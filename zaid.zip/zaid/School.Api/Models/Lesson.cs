using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace School.Api.Models
{
    public class Lesson
    {
        [Key]
        public long Id {get; set;}

        public string Name { get; set; }

        public List<Pdf> Pdfs { get; set; }

        public List<Video> Videos { get; set; }

        public string Quiz { get; set; }

        [ForeignKey("SubjectNavigation")]
        public long SubjectId { get; set; }

        public Subject SubjectNavigation { get; set; }

    }
}