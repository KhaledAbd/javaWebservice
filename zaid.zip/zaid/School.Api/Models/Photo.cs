using System.ComponentModel.DataAnnotations.Schema;

namespace School.Api.Models
{
    public class Photo
    {
        public long Id {get; set;}

        public string Description {get; set;}

        public string PublicId {get; set;}

        public string Url {get; set;}

        [ForeignKey("userNavigation")]
        public int UserId {get;set;}
        [NotMapped]
        public User userNavigation {get; set;}
    }
}