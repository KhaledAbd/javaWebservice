namespace School.Api.Dto
{
    public class PdfForLesson
    {
        public string Description {get; set;}

        public string Url {get; set;}
    }
}