using School.Api.Models;

namespace School.Api.Dto
{
    public class UserForInfoTeacherDto
    {
        public long Ssn {get; set;}

        public string Username  {get; set;}

        public string Name {get; set;}

        public Photo PhotoUrl {get; set;}

        public bool Gender {get; set;}
    }
}