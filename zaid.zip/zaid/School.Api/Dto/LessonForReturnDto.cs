using System.Collections.Generic;

namespace School.Api.Dto
{
    public class LessonForReturnDto
    {
        public long Id {get; set;}

        public string Name { get; set; }

        public List<PdfForLesson> Pdfs {get; set;}

        public List<VideoForLesson> Videos {get; set;}
    }
}