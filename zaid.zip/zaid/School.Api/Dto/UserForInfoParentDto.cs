using System.Collections.Generic;
using School.Api.Models;

namespace School.Api.Dto
{
    public class UserForInfoParentDto
    {
        public long Ssn {get; set;}

        public string Username  {get; set;}

        public string Name {get; set;}

        public string Gender {get; set;}

        public string PhotoUrl {get; set;}

        public IEnumerable<UserForInfoStudentDto> Students {get; set;}
    }
}