namespace School.Api.Dto
{
    public class PhotoForDetails
    {
        
    }
}