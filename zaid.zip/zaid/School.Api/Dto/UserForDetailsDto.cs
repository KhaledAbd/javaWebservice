namespace School.Api.Dto
{
    public class UserForDetailsDto
    {
         public int Ssn {get; set;}

        public string Username  {get; set;}

        public string Token {get; set;}

    }
}