namespace School.Api.Dto
{
    public class UserForLoginDto
    {
        public string Username {get; set;}

        public string Password{get; set;}
    }
}