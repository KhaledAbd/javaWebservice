namespace School.Api.Dto
{
    public class VideoForLesson
    {
        public string Description {get; set;}

        public string Url {get; set;}
    }
}