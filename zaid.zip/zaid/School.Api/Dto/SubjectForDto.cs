namespace School.Api.Dto
{
    public class SubjectForDto
    {
        public long Id { get; set; }

        public string Name {get; set;}

    }
}