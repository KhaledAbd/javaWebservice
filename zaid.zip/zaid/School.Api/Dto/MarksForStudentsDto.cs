namespace School.Api.Dto
{
    public class MarksForStudentsDto
    {
        public int Id {get; set;}

        public decimal Degree {get; set;}

        public decimal? FullMark {get; set;}

        public string SubjectName {get; set;}
    }
}