namespace School.Api.Dto
{
    public class UserForRegisterDto
    {
        public string Ssn {get; set;}
        public string Username {get; set;}

        public string Password {get; set;}

    }
}