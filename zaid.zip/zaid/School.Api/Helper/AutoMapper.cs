using System.Linq;
using AutoMapper;
using School.Api.Dto;
using School.Api.Models;

namespace School.Api.Helper
{
    public class AutoMapperProfile: Profile
    {
        public AutoMapperProfile(){
            CreateMap<Teacher, UserForDetailsDto>();
            CreateMap<UserForRegisterDto, Teacher>();
            CreateMap<Student, UserForDetailsDto>();
            CreateMap<UserForRegisterDto, Student>();
            CreateMap<UserForRegisterDto, Parent>();
            CreateMap<Parent, UserForDetailsDto>();
            
            CreateMap<Student, UserForInfoStudentDto>().ForMember(dest => dest.PhotoUrl, opt => {
                opt.MapFrom(src => src.Photos.SingleOrDefault(p => p.UserId == src.Ssn));
            }).ForMember(dest => dest.Gender, opt => {
                opt.MapFrom(src => src.Gender.setGender());
            }).ForMember(dest => dest.StageName, opt => opt.MapFrom(src => src.StageNavigation.Name));
            
            CreateMap<Parent, UserForInfoParentDto>().ForMember(dest => dest.PhotoUrl, opt => {
                opt.MapFrom(src => src.Photos.SingleOrDefault(p => p.UserId == src.Ssn));
            }).ForMember(dest => dest.Gender, opt => {
                opt.MapFrom(src => src.Gender.setGender());
            });

            CreateMap<Teacher, UserForInfoTeacherDto>().ForMember(dest => dest.PhotoUrl,  opt => {
                opt.MapFrom(src => src.Photos.SingleOrDefault(p => p.UserId == src.Ssn));
            }).ForMember(dest => dest.Gender, opt => {
                opt.MapFrom(src => src.Gender.setGender());
            });
            CreateMap<Subject, SubjectForDto>();
            CreateMap<Lesson, LessonForReturnDto>();
            CreateMap<Pdf, PdfForLesson>();
            CreateMap<Video, VideoForLesson>();
            CreateMap<Marks,MarksForStudentsDto>().ForMember(dest => dest.SubjectName, opt => {
                opt.MapFrom(src => src.SubjectNavigation.Name);
            }).ForMember(dest => dest.FullMark, opt => {
                opt.MapFrom(src => src.SubjectNavigation.FullMark);
            });
        }

    }
}