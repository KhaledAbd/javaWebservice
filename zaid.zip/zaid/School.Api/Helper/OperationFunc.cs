namespace School.Api.Helper
{
    public static class OperationFunc
    {
        public static string setGender(this bool gender){
            return gender ? "female": "male";
        }
    }
}